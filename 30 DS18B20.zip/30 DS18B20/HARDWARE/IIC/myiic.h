#ifndef __MYIIC_H
#define __MYIIC_H

#include "stm32f4xx.h"

void I2C1_Init(void);

#endif
