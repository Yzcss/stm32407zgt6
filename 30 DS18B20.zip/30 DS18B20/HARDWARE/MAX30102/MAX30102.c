#include "MAX30102.h"
#include "sys.h"
#include "lcd.h"

#define MAX30102_ADDRESS      0xAE  // ??? (0x57 << 1)
#define REG_FIFO_DATA         0x07
void MAX30102_WriteReg(uint8_t reg, uint8_t value)
{
    while (I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY));

    I2C_GenerateSTART(I2C1, ENABLE);
    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT));

    I2C_Send7bitAddress(I2C1, MAX30102_ADDR, I2C_Direction_Transmitter);
    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));

    I2C_SendData(I2C1, reg);
    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED));

    I2C_SendData(I2C1, value);
    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED));

    I2C_GenerateSTOP(I2C1, ENABLE);
}

uint8_t MAX30102_ReadReg(uint8_t reg)
{
    uint8_t value;

    while (I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY));

    I2C_GenerateSTART(I2C1, ENABLE);
    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT));

    I2C_Send7bitAddress(I2C1, MAX30102_ADDR, I2C_Direction_Transmitter);
    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));

    I2C_SendData(I2C1, reg);
    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED));

    I2C_GenerateSTART(I2C1, ENABLE);  // Repeated START
    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT));

    I2C_Send7bitAddress(I2C1, MAX30102_ADDR, I2C_Direction_Receiver);
    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));

    while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED));
    value = I2C_ReceiveData(I2C1);

    I2C_AcknowledgeConfig(I2C1, DISABLE);
    I2C_GenerateSTOP(I2C1, ENABLE);
    I2C_AcknowledgeConfig(I2C1, ENABLE);

    return value;
}

void MAX30102_Init(void)
{		volatile int i;
    MAX30102_WriteReg(REG_MODE_CONFIG, 0x40);  // Reset
    for (i = 0; i < 100000; i++);  // Delay

    MAX30102_WriteReg(REG_INTR_ENABLE_1, 0xC0);
    MAX30102_WriteReg(REG_FIFO_WR_PTR, 0x00);
    MAX30102_WriteReg(REG_OVF_COUNTER, 0x00);
    MAX30102_WriteReg(REG_FIFO_RD_PTR, 0x00);

    MAX30102_WriteReg(REG_FIFO_CONFIG, 0x0F);
    MAX30102_WriteReg(REG_MODE_CONFIG, 0x03);      // SPO2 mode
    MAX30102_WriteReg(REG_SPO2_CONFIG, 0x27);      // SPO2 config
    MAX30102_WriteReg(REG_LED1_PA, 0x24);          // LED1 current
    MAX30102_WriteReg(REG_LED2_PA, 0x24);          // LED2 current
}

#define I2C_TIMEOUT 10000  // ????

// ?????,?????
#define I2C_WAIT_EVENT(event)                          \
    {                                                  \
        uint32_t timeout = I2C_TIMEOUT;                \
        while (!I2C_CheckEvent(I2C1, event))           \
        {                                              \
            if (--timeout == 0)                        \
            {                                          \
                I2C_GenerateSTOP(I2C1, ENABLE);        \
                return 0;                              \
            }                                          \
        }                                              \
    }

uint8_t MAX30102_ReadFIFO(unsigned long *red, unsigned long *ir)
{
    uint8_t data[6];
    uint8_t i;

    // 1. START
    I2C_GenerateSTART(I2C1, ENABLE);
    I2C_WAIT_EVENT(I2C_EVENT_MASTER_MODE_SELECT);

    // 2. ????(?)
    I2C_Send7bitAddress(I2C1, MAX30102_ADDRESS, I2C_Direction_Transmitter);
    I2C_WAIT_EVENT(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED);

    // 3. ???????
    I2C_SendData(I2C1, REG_FIFO_DATA);
    I2C_WAIT_EVENT(I2C_EVENT_MASTER_BYTE_TRANSMITTED);

    // 4. Repeated START
    I2C_GenerateSTART(I2C1, ENABLE);
    I2C_WAIT_EVENT(I2C_EVENT_MASTER_MODE_SELECT);

    // 5. ????(?)
    I2C_Send7bitAddress(I2C1, MAX30102_ADDRESS, I2C_Direction_Receiver);
    I2C_WAIT_EVENT(I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED);

    // 6. ??6???
    for (i = 0; i < 6; i++)
    {
        uint32_t timeout = I2C_TIMEOUT;
        while (!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED))
        {
            if (--timeout == 0)
            {
                I2C_GenerateSTOP(I2C1, ENABLE);
                return 0;
            }
        }

        data[i] = I2C_ReceiveData(I2C1);

        // ?????????ACK
        if (i == 4)
            I2C_AcknowledgeConfig(I2C1, DISABLE);
    }

    // 7. STOP
    I2C_GenerateSTOP(I2C1, ENABLE);
    I2C_AcknowledgeConfig(I2C1, ENABLE);  // ????ACK

    // 8. ????
    *ir  = ((uint32_t)(data[0] & 0x03) << 16) | ((uint32_t)data[1] << 8) | data[2];
    *red = ((uint32_t)(data[3] & 0x03) << 16) | ((uint32_t)data[4] << 8) | data[5];

    return 1;
}
void MAX30102_GetHeartRate(unsigned long *irBuffer, unsigned long *redBuffer,
                           unsigned int bufferLength, int *heartRateInt, int *heartRateDec,
                           int *SPO2Int, int *SPO2Dec)
{
    unsigned long irAC = 0, redAC = 0;
    unsigned long irDC = 0, redDC = 0;
    unsigned long R = 0;
    unsigned int i;
    unsigned int peakCount = 0;
    unsigned int threshold = 0;
    unsigned int lastPeakIndex = 0;
    unsigned int minPeakDistance = 20; // ??????
    unsigned int intervals[10] = {0};
    unsigned int intervalSum = 0;
    unsigned int intervalCount = 0;

    // ?????(????)
    for (i = 0; i < bufferLength; i++) {
        irDC += irBuffer[i];
        redDC += redBuffer[i];
    }
    irDC /= bufferLength;
    redDC /= bufferLength;

    // ??????(????)
    for (i = 0; i < bufferLength; i++) {
        irAC += (irBuffer[i] > irDC) ? (irBuffer[i] - irDC) : (irDC - irBuffer[i]);
        redAC += (redBuffer[i] > redDC) ? (redBuffer[i] - redDC) : (redDC - redBuffer[i]);
    }
    irAC = irAC / bufferLength;
    redAC = redAC / bufferLength;

    if (irAC == 0 || redAC == 0 || irDC == 0 || redDC == 0) {
        *SPO2Int = 0;
        *SPO2Dec = 0;
        *heartRateInt = 0;
        *heartRateDec = 0;
        return;
    }

    // ?? SpO2
    R = (redAC * irDC * 100) / (irAC * redDC);
    if (R < 66) R = 66;        // ????
    if (R > 150) R = 150;

    *SPO2Int = (int)(110 - 25 * R / 100);
    *SPO2Dec = 0;

    // ??????????
    threshold = irDC + irAC / 2;
    for (i = 1; i < bufferLength - 1; i++) {
        if (irBuffer[i] > threshold &&
            irBuffer[i] > irBuffer[i - 1] &&
            irBuffer[i] > irBuffer[i + 1]) {
            if ((i - lastPeakIndex) > minPeakDistance) {
                if (intervalCount < 10 && lastPeakIndex > 0) {
                    intervals[intervalCount++] = i - lastPeakIndex;
                    intervalSum += i - lastPeakIndex;
                }
                peakCount++;
                lastPeakIndex = i;
            }
        }
    }

    if (intervalCount > 0) {
        unsigned int avgInterval = intervalSum / intervalCount;
        *heartRateInt = (60 * 100) / avgInterval;  // ??????100Hz
				*heartRateInt = *heartRateInt * 3 / 6-30;
    } 
    *heartRateDec = 0;
}
