#ifndef __MAX30102_H
#define __MAX30102_H

#include "stm32f4xx.h"

// MAX30102 I2C ??(7?????)
#define MAX30102_ADDR        0xAE  // ???:0xAE,???:0xAF

// ???????
#define REG_INTR_STATUS_1    0x00
#define REG_INTR_ENABLE_1    0x02
#define REG_FIFO_WR_PTR      0x04
#define REG_OVF_COUNTER      0x05
#define REG_FIFO_RD_PTR      0x06
#define REG_FIFO_DATA        0x07
#define REG_FIFO_CONFIG      0x08
#define REG_MODE_CONFIG      0x09
#define REG_SPO2_CONFIG      0x0A
#define REG_LED1_PA          0x0C
#define REG_LED2_PA          0x0D

void MAX30102_Init(void);
void MAX30102_WriteReg(uint8_t reg, uint8_t value);
uint8_t MAX30102_ReadReg(uint8_t reg);
uint8_t MAX30102_ReadFIFO(unsigned long *red, unsigned long *ir);
void MAX30102_GetHeartRate(unsigned long *irBuffer, unsigned long *redBuffer,
                           unsigned int bufferLength, int *heartRateInt, int *heartRateDec,
                           int *SPO2Int, int *SPO2Dec);
#endif
