#ifndef __ALGORITHM_H
#define __ALGORITHM_H

#include "stm32f4xx.h"

void ECG_ADC_Init(void);
uint16_t ECG_ReadValue(void);

#endif