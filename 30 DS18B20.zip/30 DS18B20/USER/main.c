#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "lcd.h"
#include "ds18b20.h"
#include "MYIIC.h"
#include "MAX30102.h"
#include "ALGORITHM.h"
#define BUFFER_SIZE 100



//ALIENTEK ̽����STM32F407������ ʵ��30
//DS18B20��ʪ�ȴ�����ʵ��-�⺯���汾 
//����֧�֣�www.openedv.com
//�Ա����̣�http://eboard.taobao.com  
//�������������ӿƼ����޹�˾  
//���ߣ�����ԭ�� @ALIENTEK
 void USART1_SendChar(char c)
{
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    USART_SendData(USART1, c);
}

// ?????
void USART1_SendString(char *str)
{
    while (*str)
    {
        USART1_SendChar(*str++);
    }
}
int main(void)
{ 
char jsonBuf[256] = {0};
unsigned long redBuffer[BUFFER_SIZE];
unsigned long irBuffer[BUFFER_SIZE];
unsigned long red_val = 0, ir_val = 0;
int heartRateInt = 0, heartRateDec = 0;
int SPO2Int = 0, SPO2Dec = 0;
int hr_int = 0, hr_dec = 0, spo2_int = 0, spo2_dec = 0;
int bufferIndex = 0;
	uint16_t ecg_value;
	char display[30];
	u8 t=0;			    
	int temperature;
	int i;
	int boyhood=0;
	int len;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init(168);  //��ʼ����ʱ����
	uart_init(115200);		//��ʼ�����ڲ�����Ϊ115200
	I2C1_Init();
	MAX30102_Init();
	ECG_ADC_Init();
	LED_Init();					//��ʼ��LED
 	LCD_Init();
  POINT_COLOR=RED;//��������Ϊ��ɫ 
	LCD_ShowString(30,50,200,16,16,"Explorer STM32F4");	
	LCD_ShowString(30,70,200,16,16,"DS18B20 TEST");	
	LCD_ShowString(30,90,200,16,16,"ATOM@ALIENTEK");
	LCD_ShowString(30,110,200,16,16,"2014/5/7");
 	while(DS18B20_Init())	//DS18B20��ʼ��	
	{
		LCD_ShowString(30,130,200,16,16,"DS18B20 Error");
		delay_ms(200);
		LCD_Fill(30,130,239,130+16,WHITE);
 		delay_ms(200);
	}
	
	LCD_ShowString(30,130,200,16,16,"DS18B20 OK");
	POINT_COLOR=BLUE;//��������Ϊ��ɫ 
 	LCD_ShowString(30,150,200,16,16,"Temp:   . C");	 
	while(1)
	{
					LCD_ShowString(30, 170, 200, 16, 16, "Collecting...");

					for (i = 0; i < BUFFER_SIZE; i++)
					{
							if (MAX30102_ReadFIFO(&red_val, &ir_val))
							{
									redBuffer[i] = red_val;
									irBuffer[i] = ir_val;
							}
							delay_ms(10);
					}

					MAX30102_GetHeartRate(irBuffer, redBuffer, BUFFER_SIZE,
																&heartRateInt, &heartRateDec,
																&SPO2Int, &SPO2Dec);

					LCD_ShowString(30, 230, 100, 16, 16, "HR:");
					LCD_ShowNum(70, 230, heartRateInt, 3, 16);  // ??????
					LCD_ShowChar(100, 230, '.', 16, 0);
					LCD_ShowNum(110, 230, heartRateDec, 2, 16); // ??????(???0)

					// ?????
					LCD_ShowString(30, 250, 100, 16, 16, "SpO2:");
					LCD_ShowNum(80, 250, SPO2Int, 3, 16);
					LCD_ShowChar(110, 250, '.', 16, 0);
					LCD_ShowNum(120, 250, SPO2Dec, 2, 16);
					LCD_ShowChar(140, 250, '%', 16, 0);
					
					
				ecg_value = ECG_ReadValue();

        sprintf(display, "ECG: %4d    ", ecg_value);
        LCD_ShowString(30, 270, 200, 16, 16, display);

        delay_ms(200);
    
 		if(t%10==0)//ÿ100ms��ȡһ��
		{									  
			temperature=DS18B20_Get_Temp();	
			if(temperature<0)
			{
				LCD_ShowChar(30+40,150,'-',16,0);			//��ʾ����
				temperature=-temperature;					//תΪ����
			}else LCD_ShowChar(30+40,150,' ',16,0);			//ȥ������
			LCD_ShowNum(30+40+8,150,temperature/10,2,16);	//��ʾ��������	    
   		LCD_ShowNum(30+40+32,150,temperature%10,1,16);	//��ʾС������ 		   
		}
		len=sprintf(jsonBuf,
        "{\"ECGSignal\":%d,\"XinLv\":%d,\"XueYang\":%d,\"Temp\":%d.%d}\n",
          ecg_value, heartRateInt, SPO2Int, temperature/10,temperature%10
                );
//		for(i=0;i<len;i++){
//			printf("%c",jsonBuf[i]);
//		}
		USART1_SendString(jsonBuf);
	 	delay_ms(10);
		t++;
		if(t==20)
		{
			t=0;
			LED0=!LED0;
		}
	}
}