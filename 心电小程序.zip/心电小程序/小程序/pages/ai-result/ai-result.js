Page({
  data: {
    result: ''
  },

  onLoad(options) {
    if (options && options.result) {
      this.setData({
        result: decodeURIComponent(options.result)
      });
    }
  }
});
