import mqtt from '../../utils/mqtt.min.js';
import * as echarts from '../../components/ec-canvas/echarts';

let ecgData = new Array(100).fill(0);  // 初始心电图数据

Page({
  data: {
    Temp: 0,
    ECGSignal: 0,
    XueYang: 0,
    XinLv: 0,
    ecgOption: { lazyLoad: true },
    healthRecords: [], // 新增用于记录数据
  },

  onLoad() {
    this.connectToMQTT();
  },

  onReady() {
    this.initECGChart();
  },

  connectToMQTT() {
    const host = "wxs://iot-06z00im8ltsevdk.mqtt.iothub.aliyuncs.com:443/mqtt";
    const options = {
      connectTimeout: 5000,
      clientId: "k0c2inJBk3h.XindianWeChat|securemode=2,signmethod=hmacsha256,timestamp=1751713241720|",
      username: "XindianWeChat&k0c2inJBk3h",
      password: "9baaba43be2c900ac8784d98ef21eca9f03fcdc0d020450d494b430cdae90d69",
      clean: true
    };

    const client = mqtt.connect(host, options);
    const that = this;

    client.on('connect', () => {
      console.log('✅ MQTT已连接');
      client.subscribe('/k0c2inJBk3h/XindianWeChat/user/get', (err) => {
        if (!err) console.log('📡 已订阅Topic');
      });
    });

    client.on('message', (topic, message) => {
      try {
        const json = JSON.parse(message.toString());
        const data = json.params;

        const { Temp = 0, ECGSignal = 0, XueYang = 0, XinLv = 0 } = data;

        that.setData({ Temp, ECGSignal, XueYang, XinLv });

        ecgData.push(ECGSignal);
        ecgData.shift();

        // 更新心电图
        if (that.ecgChart) {
          that.ecgChart.setOption({ series: [{ data: ecgData }] });
        }

        // 记录用于导出分析
        that.data.healthRecords.push([Temp, XinLv, XueYang, ECGSignal]);

      } catch (e) {
        console.error('🚨 数据解析失败', e);
      }
    });

    client.on('error', (err) => {
      console.error("🚫 MQTT连接出错：", err);
    });
  },

  initECGChart() {
    const that = this;
    this.selectComponent('#ecg').init((canvas, width, height, dpr) => {
      const chart = echarts.init(canvas, null, {
        width,
        height,
        devicePixelRatio: dpr
      });
      canvas.setChart(chart);
      that.ecgChart = chart;

      const option = {
        animation: false,
        grid: { left: 0, right: 0, top: 10, bottom: 0 },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: Array.from({ length: 100 }, (_, i) => i),
          show: false
        },
        yAxis: {
          type: 'value',
          min: 0,
          max: 4000,
          show: false
        },
        series: [{
          name: 'ECG',
          type: 'line',
          data: ecgData,
          showSymbol: false,
          lineStyle: {
            color: '#ff4d4f',
            width: 2
          }
        }]
      };

      chart.setOption(option);
      console.log("📊 ECharts 图表初始化完成");
      return chart;
    });
  },

  // 导出 CSV
  exportHealthCSV() {
    const header = ["Temp", "XinLv", "XueYang", "ECGSignal"];
    const csvContent = [
      header,
      ...this.data.healthRecords
    ].map(row => row.join(",")).join("\n");

    const filePath = wx.env.USER_DATA_PATH + '/health_data.csv';

    wx.getFileSystemManager().writeFile({
      filePath,
      data: csvContent,
      encoding: 'utf8',
      success: () => {
        wx.showToast({ title: '✅ 数据已保存' });
        console.log("📁 保存路径:", filePath);
      },
      fail: () => {
        wx.showToast({ title: '❌ 保存失败', icon: 'none' });
      }
    });
  },

  // AI分析
  analyzeHealthWithAI() {
    const records = this.data.healthRecords;
    if (records.length === 0) {
      wx.showToast({ title: '暂无数据可分析', icon: 'none' });
      return;
    }

    wx.showLoading({ title: 'AI分析中...' });

    const header = ["Temp", "XinLv", "XueYang", "ECGSignal"];
    const csvContent = [
      header,
      ...records
    ].map(row => row.join(",")).join("\n");

    const date = new Date().toUTCString();
    const apiKey = "XWLkjmPOTXGVSSMCchEz:nWwhAoLDdKEnXiAXwzMQ";

    wx.request({
      url: 'https://spark-api-open.xf-yun.com/v2/chat/completions',
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'Date': date
      },
      data: {
        model: "x1",
        user: "d110f98e",
        messages: [
          { role: 'user', content: "请根据以下体征数据（体温、心率、血氧、心电信号）生成健康评估和建议：" },
          { role: 'user', content: csvContent }
        ]
      },
      success: (res) => {
        wx.hideLoading();
        const reply = res?.data?.choices?.[0]?.message?.content || "分析失败";
        wx.navigateTo({
          url: '/pages/ai-result/ai-result?result=' + encodeURIComponent(reply)
        });
      },
      fail: (err) => {
        wx.hideLoading();
        console.error("❌ 请求失败", err);
        wx.showToast({ title: 'AI请求失败', icon: 'none' });
      }
    });
  }
});
